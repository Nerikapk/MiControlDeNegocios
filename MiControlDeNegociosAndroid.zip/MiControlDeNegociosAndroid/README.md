# Mi Control de Negocios — proyecto Android

Este proyecto empaqueta la versión HTML actual de **Mi Control de Negocios** dentro de una app Android con WebView. La aplicación funciona sin conexión y conserva los datos en el almacenamiento local de la app mediante `localStorage`.

## Opción 1: compilar en Android Studio

1. En una computadora, instala Android Studio y el JDK 17.
2. Descomprime este proyecto.
3. Abre Android Studio y elige **Open**; selecciona la carpeta `MiControlDeNegociosAndroid`.
4. Espera a que termine la sincronización de Gradle y acepta instalar el Android SDK 35 si te lo solicita.
5. En el menú **Build**, elige **Build Bundle(s) / APK(s) > Build APK(s)**.
6. Cuando termine, encontrarás el APK en:
   `app/build/outputs/apk/debug/app-debug.apk`
7. Pasa ese archivo a tu teléfono Android, ábrelo y autoriza la instalación desde esa fuente si Android te lo pide.

## Opción 2: compilar en GitHub sin instalar Android Studio

1. Inicia sesión o crea una cuenta en GitHub.
2. Crea un repositorio nuevo y sube el contenido de esta carpeta (incluida la carpeta oculta `.github`).
3. Abre la pestaña **Actions** del repositorio.
4. Ejecuta el flujo **Compilar APK de Mi Control de Negocios** con **Run workflow**, o haz un push a la rama `main`.
5. Cuando termine correctamente, abre la ejecución y descarga el artefacto `Mi-Control-de-Negocios-APK`.
6. Descomprime el artefacto: dentro estará `app-debug.apk`. Envíalo al teléfono e instálalo.

## Respaldo seguro y restauración

- Los datos de trabajo se guardan localmente en este teléfono; no se sincronizan automáticamente a un servidor.
- **Guardar respaldo seguro** cifra una copia con AES-GCM y una contraseña derivada mediante PBKDF2. El archivo termina en `.mcnbackup` y no es un JSON legible sin descifrar.
- Al guardar, el selector de archivos de Android puede mostrar Google Drive si está instalado y conectado; selecciona Drive como destino para guardar la copia en la nube.
- **Restaurar respaldo** permite elegir un archivo de respaldo cifrado y recuperarlo con su contraseña. La restauración reemplaza los datos actuales, así que primero crea un respaldo de los datos actuales.
- **Compartir respaldo como documento** abre el menú de compartir de Android; puedes elegir WhatsApp, Drive u otra aplicación disponible.
- Usa una contraseña única de al menos 8 caracteres, idealmente una frase larga, y guárdala en un gestor de contraseñas o en otro lugar seguro. Si la pierdes, el archivo cifrado no se puede recuperar.
- No compartas el archivo ni la contraseña en el mismo mensaje. Para máxima seguridad, usa Google Drive con verificación en dos pasos y guarda también una segunda copia en otro lugar seguro.
- No desinstales la aplicación ni borres sus datos sin guardar primero un respaldo.
- Esta primera versión agrega una pantalla Android alrededor de la aplicación web; no es una app publicada en Google Play.
- El APK `debug` sirve para instalación y pruebas. Para distribución formal se recomienda generar una versión `release` firmada y guardar de forma segura su clave de firma.

## Requisitos técnicos

- Android Studio reciente, Android SDK 35 y JDK 17 para compilar localmente.
- El proyecto usa Android Gradle Plugin 8.7.3 y Gradle 8.9.


## Recordatorio semanal de respaldo

La aplicación Android programa una notificación cada 7 días para recordar que guardes un respaldo cifrado. La primera vez que abras la app, Android puede pedir permiso para mostrar notificaciones: acepta para recibir el aviso. Al guardar un respaldo desde “Guardar respaldo seguro”, el plazo se reinicia automáticamente. También puedes tocar “Ya hice el respaldo esta semana” después de guardarlo por otro medio. El recordatorio no crea copias automáticas; solo avisa. Si las notificaciones están desactivadas en los ajustes del teléfono, el aviso no aparecerá.
