package com.micontrol.negocios;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.os.Build;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import androidx.core.content.FileProvider;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;

public class MainActivity extends Activity {
    private static final int CREATE_BACKUP_REQUEST = 4817;
    private static final int OPEN_BACKUP_REQUEST = 4818;
    private static final int ITERATIONS = 210000;
    private static final int NOTIFICATION_PERMISSION_REQUEST = 4819;
    private static final int KEY_BITS = 256;
    private WebView webView;
    private String pendingBackupEncrypted;
    private String pendingRestorePassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        BackupReminderReceiver.ensureScheduled(this);
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.POST_NOTIFICATIONS}, NOTIFICATION_PERMISSION_REQUEST);
        }
        webView = new WebView(this);
        setContentView(webView);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setAllowFileAccess(true);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new AndroidBridge(), "AndroidBridge");
        webView.loadUrl("file:///android_asset/index.html");
    }

    private class AndroidBridge {
        @JavascriptInterface
        public void exportEncryptedBackup(String json, String password) {
            try {
                pendingBackupEncrypted = encrypt(json, password);
                runOnUiThread(() -> {
                    Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType("application/octet-stream");
                    intent.putExtra(Intent.EXTRA_TITLE, "MiControlDeNegocios-respaldo.mcnbackup");
                    startActivityForResult(intent, CREATE_BACKUP_REQUEST);
                });
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "No se pudo cifrar el respaldo", Toast.LENGTH_LONG).show());
            }
        }

        @JavascriptInterface
        public void shareEncryptedBackup(String json, String password) {
            try {
                String encrypted = encrypt(json, password);
                File file = new File(getCacheDir(), "MiControlDeNegocios-respaldo.mcnbackup");
                try (OutputStream out = new java.io.FileOutputStream(file)) {
                    out.write(encrypted.getBytes(StandardCharsets.UTF_8));
                }
                Uri uri = FileProvider.getUriForFile(MainActivity.this, getPackageName() + ".fileprovider", file);
                Intent share = new Intent(Intent.ACTION_SEND);
                share.setType("application/octet-stream");
                share.putExtra(Intent.EXTRA_STREAM, uri);
                share.putExtra(Intent.EXTRA_SUBJECT, "Respaldo cifrado de Mi Control de Negocios");
                share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                runOnUiThread(() -> startActivity(Intent.createChooser(share, "Compartir respaldo cifrado")));
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "No se pudo preparar el respaldo para compartir", Toast.LENGTH_LONG).show());
            }
        }

        @JavascriptInterface
        public void confirmBackupDone() {
            BackupReminderReceiver.resetReminder(MainActivity.this);
            runOnUiThread(() -> Toast.makeText(MainActivity.this, "Recordatorio actualizado: te avisaremos la próxima semana.", Toast.LENGTH_LONG).show());
        }

        public void importBackup(String password) {
            pendingRestorePassword = password;
            runOnUiThread(() -> {
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("*/*");
                startActivityForResult(intent, OPEN_BACKUP_REQUEST);
            });
        }
    }

    private String encrypt(String plainText, String password) throws Exception {
        byte[] salt = new byte[16];
        byte[] iv = new byte[12];
        SecureRandom random = new SecureRandom();
        random.nextBytes(salt);
        random.nextBytes(iv);
        SecretKeySpec key = deriveKey(password, salt);
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.ENCRYPT_MODE, key, new GCMParameterSpec(128, iv));
        byte[] encrypted = cipher.doFinal(plainText.getBytes(StandardCharsets.UTF_8));
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        bytes.write("MCN1".getBytes(StandardCharsets.UTF_8));
        bytes.write(salt);
        bytes.write(iv);
        bytes.write(encrypted);
        return Base64.encodeToString(bytes.toByteArray(), Base64.NO_WRAP);
    }

    private String decrypt(String encoded, String password) throws Exception {
        byte[] all = Base64.decode(encoded.trim(), Base64.DEFAULT);
        if (all.length < 4 + 16 + 12 + 16) throw new IllegalArgumentException("Archivo demasiado corto");
        String magic = new String(all, 0, 4, StandardCharsets.UTF_8);
        if (!"MCN1".equals(magic)) throw new IllegalArgumentException("Formato de respaldo desconocido");
        byte[] salt = java.util.Arrays.copyOfRange(all, 4, 20);
        byte[] iv = java.util.Arrays.copyOfRange(all, 20, 32);
        byte[] encrypted = java.util.Arrays.copyOfRange(all, 32, all.length);
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.DECRYPT_MODE, deriveKey(password, salt), new GCMParameterSpec(128, iv));
        return new String(cipher.doFinal(encrypted), StandardCharsets.UTF_8);
    }

    private SecretKeySpec deriveKey(String password, byte[] salt) throws Exception {
        PBEKeySpec spec = new PBEKeySpec(password.toCharArray(), salt, ITERATIONS, KEY_BITS);
        try {
            byte[] key = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).getEncoded();
            return new SecretKeySpec(key, "AES");
        } finally {
            spec.clearPassword();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent resultData) {
        super.onActivityResult(requestCode, resultCode, resultData);
        if (requestCode == CREATE_BACKUP_REQUEST) {
            if (resultCode == RESULT_OK && resultData != null && resultData.getData() != null) {
                try (OutputStream output = getContentResolver().openOutputStream(resultData.getData())) {
                    if (output == null) throw new IllegalStateException("No se pudo abrir el archivo");
                    output.write((pendingBackupEncrypted == null ? "" : pendingBackupEncrypted).getBytes(StandardCharsets.UTF_8));
                    BackupReminderReceiver.resetReminder(this);
                    Toast.makeText(this, "Respaldo cifrado guardado. Recuerda tu contraseña.", Toast.LENGTH_LONG).show();
                } catch (Exception e) {
                    Toast.makeText(this, "No se pudo guardar el respaldo", Toast.LENGTH_LONG).show();
                }
            }
            pendingBackupEncrypted = null;
        } else if (requestCode == OPEN_BACKUP_REQUEST) {
            if (resultCode == RESULT_OK && resultData != null && resultData.getData() != null) {
                try (InputStream input = getContentResolver().openInputStream(resultData.getData())) {
                    if (input == null) throw new IllegalStateException("No se pudo leer el archivo");
                    ByteArrayOutputStream bytes = new ByteArrayOutputStream();
                    byte[] buffer = new byte[8192];
                    int count;
                    while ((count = input.read(buffer)) != -1) bytes.write(buffer, 0, count);
                    String json = decrypt(bytes.toString(StandardCharsets.UTF_8.name()), pendingRestorePassword == null ? "" : pendingRestorePassword);
                    String encoded = Base64.encodeToString(json.getBytes(StandardCharsets.UTF_8), Base64.NO_WRAP);
                    webView.evaluateJavascript("window.receiveRestoredBackupBase64('" + encoded + "')", null);
                } catch (Exception e) {
                    Toast.makeText(this, "No se pudo restaurar. Revisa el archivo y la contraseña.", Toast.LENGTH_LONG).show();
                }
            }
            pendingRestorePassword = null;
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
