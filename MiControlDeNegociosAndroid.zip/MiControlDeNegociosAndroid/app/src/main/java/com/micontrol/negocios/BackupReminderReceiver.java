package com.micontrol.negocios;

import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

public class BackupReminderReceiver extends BroadcastReceiver {
    private static final String PREFS = "backup_reminder";
    private static final String KEY_DUE = "due_at";
    private static final String CHANNEL_ID = "weekly_backup_reminder";
    private static final long WEEK_MS = 7L * 24L * 60L * 60L * 1000L;

    @Override
    public void onReceive(Context context, Intent intent) {
        if (Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) {
            ensureScheduled(context);
            return;
        }
        createChannel(context);
        if (Build.VERSION.SDK_INT < 33 || context.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) {
            Intent openApp = new Intent(context, MainActivity.class);
            PendingIntent contentIntent = PendingIntent.getActivity(context, 4820, openApp, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            NotificationCompat.Builder notification = new NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("Hora de respaldar tus negocios")
                .setContentText("Guarda el respaldo de Mi Control de Negocios para proteger tus registros.")
                .setStyle(new NotificationCompat.BigTextStyle().bigText("Abre Mi Control de Negocios y toca ‘Guardar respaldo seguro’. El recordatorio no guarda los datos automáticamente."))
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setAutoCancel(true)
                .setContentIntent(contentIntent);
            NotificationManagerCompat.from(context).notify(4821, notification.build());
        }
        resetReminder(context);
    }

    static void ensureScheduled(Context context) {
        long due = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getLong(KEY_DUE, 0L);
        if (due == 0L) resetReminder(context);
        else schedule(context, due);
    }

    static void resetReminder(Context context) {
        long due = System.currentTimeMillis() + WEEK_MS;
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putLong(KEY_DUE, due).apply();
        schedule(context, due);
    }

    private static void schedule(Context context, long due) {
        AlarmManager alarms = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        Intent intent = new Intent(context, BackupReminderReceiver.class);
        PendingIntent pending = PendingIntent.getBroadcast(context, 4821, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        if (alarms != null) alarms.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, Math.max(due, System.currentTimeMillis() + 1000L), pending);
    }

    private static void createChannel(Context context) {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "Recordatorios de respaldo", NotificationManager.IMPORTANCE_DEFAULT);
            channel.setDescription("Avisos semanales para respaldar los datos de tus negocios");
            NotificationManager manager = context.getSystemService(NotificationManager.class);
            if (manager != null) manager.createNotificationChannel(channel);
        }
    }
}
